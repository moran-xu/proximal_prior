To reproduce the results shown in the supplementary materials, please run the following code:

For results in Figure 1 and Table 1 --- run the following files:

rjmcmc_sparse.py
sparse_regression_Table1_sup.py
N_prior.R

For results in Figure 2 and 3 --- run hmc_converge_Figure2&3_sup.py

For results in Table 2 ---  run the following files:
bimf.m
rjmcmc_factor_exact.py
infinite_factor_proximal.py

